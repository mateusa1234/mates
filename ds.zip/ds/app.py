from flask import Flask, render_template, request, redirect, url_for, session, g
import sqlite3
import hashlib

app = Flask(__name__, template_folder='my_website/templates')
app.secret_key = 'nananinomatemarkoziekaterinetinatiniluka'

DATABASE = 'user_database.db'

# Connect to SQLite database
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

# Create table if not exists
def init_db():
    with app.app_context():
        cursor = get_db().cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS users
                        (id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT NOT NULL UNIQUE,
                        password TEXT NOT NULL)''')
        get_db().commit()

init_db()

@app.route('/')
def index():
    # Check if the user is already logged in
    if 'username' in session:
        return redirect(url_for('home'))
    # Check if the registration was successful
    if 'registered' in session and session['registered']:
        # Clear the 'registered' session variable
        session.pop('registered', None)
        return redirect(url_for('login'))
    # Otherwise, redirect to the register page
    return redirect(url_for('register'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # Hash the password before storing it
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        
        try:
            cursor = get_db().cursor()
            cursor.execute('''INSERT INTO users (username, password) 
                            VALUES (?, ?)''', (username, hashed_password))
            get_db().commit()
            session['registered'] = True
            return redirect(url_for('login'))  # Redirect to login after successful registration
        except sqlite3.IntegrityError:
            return "Username already exists. Please choose a different one."
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # Hash the password to compare with the stored hash
        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        cursor = get_db().cursor()
        cursor.execute('''SELECT * FROM users 
                        WHERE username=? AND password=?''', (username, hashed_password))
        user = cursor.fetchone()
        if user:
            session['username'] = username
            return redirect(url_for('home'))
        else:
            return "Invalid username or password."
    return render_template('login.html')

@app.route('/home')
def home():
    # Check if the user is logged in
    if 'username' in session:
        return render_template('home.html')
    else:
        return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
